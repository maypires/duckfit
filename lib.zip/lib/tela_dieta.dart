import 'package:flutter/material.dart';

class TelaDieta extends StatelessWidget {
  const TelaDieta({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Dieta', style: TextStyle(fontSize: 24, color: Colors.white)),
    );
  }
}
