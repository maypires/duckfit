import 'package:flutter/material.dart';

class TelaTreino extends StatelessWidget {
  const TelaTreino({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Treino', style: TextStyle(fontSize: 24, color: Colors.white)),
    );
  }
}